/**
 * ═══════════════════════════════════════════════════════════════
 * NIGHT SKY DIGITAL ALBUM — script.js
 * Sections:
 *   1. DATA          — gallery items, thoughts, music
 *   2. STATE         — app-wide mutable state
 *   3. STARS         — canvas star field
 *   4. PARALLAX      — moon scroll effect
 *   5. GATE          — password screen logic
 *   6. NAVIGATION    — bottom nav / view router
 *   7. HOME PAGE     — hero, thoughts, video rendering
 *   8. GALLERY       — card rendering
 *   9. MUSIC PLAYER  — audio controls, modal
 *  10. SCROLL ANIM   — IntersectionObserver fade-ins
 *  11. INIT          — bootstrap
 * ═══════════════════════════════════════════════════════════════
 */

'use strict';

/* ══════════════════════════════════════════════
   1. DATA
══════════════════════════════════════════════ */

/** Hardcoded password — change to your own */
const PASSWORD = '01062024';

/**
 * Thoughts shown on the home page.
 * Replace ADD_YOUR_TEXT_HERE with real lines.
 */
const thoughtsData = [
  { line: 'ADD_YOUR_TEXT_HERE' },
  { line: 'ADD_YOUR_TEXT_HERE' },
  { line: 'ADD_YOUR_TEXT_HERE' },
  { line: 'ADD_YOUR_TEXT_HERE' },
];

/**
 * Gallery items — add/remove objects freely.
 * mediaType: "image" | "video"
 * src: path to asset (e.g. "assets/images/photo1.jpg")
 * text: memory caption
 */
const galleryData = [
  { mediaType: 'image',  src: 'assets/images/sample.jpg',   text: 'ADD_MEMORY_TEXT' },
  { mediaType: 'image',  src: 'assets/images/sample2.jpg',  text: 'ADD_MEMORY_TEXT' },
  { mediaType: 'video',  src: 'assets/videos/sample.mp4',   text: 'ADD_MEMORY_TEXT' },
  { mediaType: 'image',  src: 'assets/images/sample3.jpg',  text: 'ADD_MEMORY_TEXT' },
  { mediaType: 'image',  src: 'assets/images/sample4.jpg',  text: 'ADD_MEMORY_TEXT' },
  { mediaType: 'image',  src: 'assets/images/sample5.jpg',  text: 'ADD_MEMORY_TEXT' },
];

/**
 * Music playlist — add/remove objects freely.
 * name: display name
 * file: filename inside assets/audio/
 */
const musicList = [
  { name: 'ADD_SONG_NAME',  file: 'ADD_AUDIO_HERE.mp3' },
  { name: 'ADD_SONG_NAME',  file: 'ADD_AUDIO_HERE.mp3' },
  { name: 'ADD_SONG_NAME',  file: 'ADD_AUDIO_HERE.mp3' },
];


/* ══════════════════════════════════════════════
   2. STATE
══════════════════════════════════════════════ */

const state = {
  currentView: 'home',    // 'home' | 'gallery'
  musicModalOpen: false,
  audio: {
    currentIndex: -1,     // index in musicList
    isPlaying: false,
  },
};


/* ══════════════════════════════════════════════
   3. STAR CANVAS
══════════════════════════════════════════════ */

(function initStars() {
  const canvas = document.getElementById('starCanvas');
  const ctx = canvas.getContext('2d');

  // Star data
  const STAR_COUNT = 220;
  const stars = [];

  /** Resize canvas to match viewport */
  function resize() {
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;
  }

  /** Generate random stars */
  function generateStars() {
    stars.length = 0;
    for (let i = 0; i < STAR_COUNT; i++) {
      stars.push({
        x:       Math.random() * canvas.width,
        y:       Math.random() * canvas.height,
        r:       Math.random() * 1.4 + 0.2,
        opacity: Math.random() * 0.8 + 0.2,
        speed:   Math.random() * 0.012 + 0.004,   // twinkle speed
        phase:   Math.random() * Math.PI * 2,      // twinkle phase offset
        // Shooting star chance (rare)
        isShooting: false,
        shootX: 0, shootY: 0, shootLen: 0, shootAlpha: 0,
      });
    }
  }

  let then = performance.now();

  function drawStars(now) {
    const delta = (now - then) / 1000;
    then = now;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    for (const s of stars) {
      // Twinkle
      s.phase += s.speed * delta * 60;
      const alpha = s.opacity * (0.5 + 0.5 * Math.sin(s.phase));

      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(255,255,255,${alpha})`;
      ctx.fill();
    }

    requestAnimationFrame(drawStars);
  }

  // Occasional shooting star
  function spawnShootingStar() {
    const sx = Math.random() * canvas.width * 0.7;
    const sy = Math.random() * canvas.height * 0.4;
    const len = 80 + Math.random() * 120;
    const angle = Math.PI / 6 + Math.random() * Math.PI / 8;
    const duration = 700 + Math.random() * 500;
    const ex = sx + Math.cos(angle) * len;
    const ey = sy + Math.sin(angle) * len;
    const start = performance.now();

    function drawShot(now) {
      const t = Math.min((now - start) / duration, 1);
      const ease = t < 0.5 ? 2*t*t : -1+(4-2*t)*t;
      const alpha = t < 0.5 ? ease : 1 - ease;
      const cx = sx + (ex - sx) * ease;
      const cy = sy + (ey - sy) * ease;
      const tailLen = len * 0.35;
      const tx = cx - Math.cos(angle) * tailLen;
      const ty = cy - Math.sin(angle) * tailLen;

      const grad = ctx.createLinearGradient(tx, ty, cx, cy);
      grad.addColorStop(0, `rgba(255,255,255,0)`);
      grad.addColorStop(1, `rgba(255,248,220,${alpha * 0.9})`);

      ctx.beginPath();
      ctx.moveTo(tx, ty);
      ctx.lineTo(cx, cy);
      ctx.strokeStyle = grad;
      ctx.lineWidth = 1.5;
      ctx.stroke();

      if (t < 1) requestAnimationFrame(drawShot);
    }
    requestAnimationFrame(drawShot);
  }

  function scheduleShootingStar() {
    const delay = 5000 + Math.random() * 12000;
    setTimeout(() => {
      spawnShootingStar();
      scheduleShootingStar();
    }, delay);
  }

  window.addEventListener('resize', () => { resize(); generateStars(); });
  resize();
  generateStars();
  requestAnimationFrame(drawStars);
  scheduleShootingStar();
})();


/* ══════════════════════════════════════════════
   4. PARALLAX (moon on scroll)
══════════════════════════════════════════════ */

(function initParallax() {
  const moon = document.getElementById('moon');
  if (!moon) return;

  window.addEventListener('scroll', () => {
    const scrollY = window.scrollY;
    // Moon moves up slightly as user scrolls down
    moon.style.transform = `translateY(${scrollY * -0.08}px)`;
  }, { passive: true });
})();


/* ══════════════════════════════════════════════
   5. GATE — password screen logic
══════════════════════════════════════════════ */

(function initGate() {
  const gateScreen   = document.getElementById('gateScreen');
  const app          = document.getElementById('app');
  const inputWrapper = document.getElementById('inputWrapper');
  const passwordInput = document.getElementById('passwordInput');
  const unlockBtn    = document.getElementById('unlockBtn');
  const gateError    = document.getElementById('gateError');

  /** Show the app with smooth transition */
  function unlock() {
    gateScreen.classList.add('gate-fadeout');
    gateScreen.addEventListener('animationend', () => {
      gateScreen.classList.add('hidden');
      gateScreen.classList.remove('active');
      app.classList.remove('hidden');
      app.classList.add('reveal');
    }, { once: true });
  }

  /** Show error shake */
  function showError() {
    gateError.classList.add('visible');
    inputWrapper.classList.add('shake');
    passwordInput.value = '';

    inputWrapper.addEventListener('animationend', () => {
      inputWrapper.classList.remove('shake');
    }, { once: true });

    setTimeout(() => gateError.classList.remove('visible'), 3000);
  }

  function checkPassword() {
    const val = passwordInput.value.trim();
    if (val === PASSWORD) {
      unlock();
    } else {
      showError();
    }
  }

  unlockBtn.addEventListener('click', checkPassword);

  passwordInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') checkPassword();
  });
})();


/* ══════════════════════════════════════════════
   6. NAVIGATION — view router
══════════════════════════════════════════════ */

(function initNav() {
  const navItems = document.querySelectorAll('.nav-item');

  navItems.forEach(item => {
    item.addEventListener('click', () => {
      const target = item.dataset.view;

      if (target === 'music') {
        openMusicModal();
        return;
      }

      // Update active tab
      navItems.forEach(n => n.classList.remove('active'));
      item.classList.add('active');

      // Switch views
      switchView(target);
    });
  });
})();

/**
 * Switch between 'home' and 'gallery' views.
 * @param {string} viewName
 */
function switchView(viewName) {
  if (state.currentView === viewName) return;

  const current = document.querySelector('.active-view');
  const next = document.getElementById(
    viewName === 'home' ? 'viewHome' : 'viewGallery'
  );

  if (current) {
    current.classList.remove('active-view');
    current.classList.add('hidden-view');
  }

  if (next) {
    next.classList.remove('hidden-view');
    next.classList.add('active-view');
  }

  state.currentView = viewName;

  // Scroll to top on view change
  window.scrollTo({ top: 0, behavior: 'smooth' });

  // Re-run intersection observers for new view content
  setTimeout(observeElements, 300);
}


/* ══════════════════════════════════════════════
   7. HOME PAGE — render thoughts & video
══════════════════════════════════════════════ */

(function renderHome() {
  renderThoughts();
  initVideoSection();
})();

/** Render thoughts cards from thoughtsData */
function renderThoughts() {
  const grid = document.getElementById('thoughtsGrid');
  if (!grid) return;

  grid.innerHTML = '';

  thoughtsData.forEach((thought, i) => {
    const card = document.createElement('div');
    card.className = 'thought-card fade-up';

    card.innerHTML = `
      <p class="thought-num">✦ ${String(i + 1).padStart(2, '0')}</p>
      <p class="thought-line">${escapeHTML(thought.line)}</p>
    `;

    grid.appendChild(card);
  });
}

/** Check if video source is a placeholder and show overlay accordingly */
function initVideoSection() {
  const video       = document.getElementById('specialVideo');
  const placeholder = document.getElementById('videoPlaceholder');

  if (!video || !placeholder) return;

  const source = video.querySelector('source');
  const src    = source ? source.getAttribute('src') : '';

  // Hide placeholder if a real src is provided
  if (src && src !== 'ADD_SPECIAL_VIDEO_HERE') {
    placeholder.classList.add('hidden');
  }

  // When video starts loading real data, hide the placeholder
  video.addEventListener('loadedmetadata', () => {
    placeholder.classList.add('hidden');
  });
}


/* ══════════════════════════════════════════════
   8. GALLERY — render cards
══════════════════════════════════════════════ */

(function renderGallery() {
  const grid = document.getElementById('galleryGrid');
  if (!grid) return;

  grid.innerHTML = '';

  galleryData.forEach((item, i) => {
    const card = document.createElement('article');
    card.className = 'gallery-card fade-up';
    // Stagger delay for cascade effect
    card.style.transitionDelay = `${(i % 3) * 0.1}s`;

    const mediaEl = buildMediaElement(item, i);

    card.innerHTML = `
      <div class="card-media">${mediaEl}</div>
      <div class="card-body">
        <p class="card-index">Memory ${String(i + 1).padStart(2, '0')}</p>
        <p class="card-text">${escapeHTML(item.text)}</p>
      </div>
    `;

    grid.appendChild(card);
  });
})();

/**
 * Build the media element HTML string for a gallery item.
 * Falls back to a placeholder div if src is a placeholder string.
 * @param {object} item
 * @param {number} index
 * @returns {string}
 */
function buildMediaElement(item, index) {
  const isPlaceholderSrc = !item.src || item.src.includes('ADD_');

  if (isPlaceholderSrc) {
    const emoji = item.mediaType === 'video' ? '▶' : '✦';
    const label = item.mediaType === 'video' ? 'Add Video' : 'Add Image';
    return `
      <div class="card-media-placeholder">
        <span>${emoji}</span>
        <span>${label}</span>
      </div>
    `;
  }

  if (item.mediaType === 'video') {
    return `
      <video
        src="${escapeHTML(item.src)}"
        controls
        playsinline
        preload="none"
        loading="lazy"
        aria-label="Memory video ${index + 1}"
      ></video>
    `;
  }

  return `
    <img
      src="${escapeHTML(item.src)}"
      alt="Memory ${index + 1}"
      loading="lazy"
      onerror="this.parentElement.innerHTML='<div class=card-media-placeholder><span>✦</span><span>Image not found</span></div>'"
    />
  `;
}


/* ══════════════════════════════════════════════
   9. MUSIC PLAYER
══════════════════════════════════════════════ */

(function initMusicPlayer() {
  const audio          = document.getElementById('audioPlayer');
  const modal          = document.getElementById('musicModal');
  const backdrop       = document.getElementById('musicBackdrop');
  const closeBtn       = document.getElementById('musicClose');
  const playPauseBtn   = document.getElementById('playPauseBtn');
  const prevBtn        = document.getElementById('prevBtn');
  const nextBtn        = document.getElementById('nextBtn');
  const songList       = document.getElementById('songList');
  const progressBar    = document.getElementById('progressBar');
  const progressFill   = document.getElementById('progressFill');
  const progressThumb  = document.getElementById('progressThumb');
  const volumeSlider   = document.getElementById('volumeSlider');
  const npSong         = document.getElementById('npSong');
  const npStatus       = document.getElementById('npStatus');
  const npDisc         = document.getElementById('npDisc');
  const timeElapsed    = document.getElementById('timeElapsed');
  const timeDuration   = document.getElementById('timeDuration');

  // Set initial volume
  audio.volume = parseFloat(volumeSlider.value);

  // ── Render song list ──────────────────────────────
  renderSongList();

  function renderSongList() {
    songList.innerHTML = '';

    if (musicList.length === 0) {
      songList.innerHTML = `<li style="text-align:center;color:var(--col-text-subtle);padding:20px;font-size:0.85rem;letter-spacing:0.1em;">No songs added yet</li>`;
      return;
    }

    musicList.forEach((song, i) => {
      const li = document.createElement('li');
      li.className = 'song-item';
      li.setAttribute('role', 'option');
      li.setAttribute('aria-label', `Song: ${song.name}`);
      li.dataset.index = i;

      li.innerHTML = `
        <span class="song-num">${String(i + 1).padStart(2, '0')}</span>
        <span class="song-name">${escapeHTML(song.name)}</span>
        <span class="song-play-icon">▶</span>
      `;

      li.addEventListener('click', () => loadAndPlay(i));
      songList.appendChild(li);
    });
  }

  // ── Load & play a song ───────────────────────────
  function loadAndPlay(index) {
    if (index < 0 || index >= musicList.length) return;

    state.audio.currentIndex = index;
    const song = musicList[index];

    audio.src = `assets/audio/${song.file}`;
    audio.load();
    audio.play().catch(err => {
      console.warn('Audio play failed:', err);
      npStatus.textContent = 'Could not play';
    });

    updateNowPlayingUI(song.name, 'Playing');
    highlightSong(index);
  }

  function updateNowPlayingUI(name, status) {
    npSong.textContent   = name;
    npStatus.textContent = status;
  }

  function highlightSong(index) {
    document.querySelectorAll('.song-item').forEach((el, i) => {
      el.classList.toggle('playing', i === index);
    });
  }

  // ── Play / Pause ─────────────────────────────────
  function togglePlay() {
    if (state.audio.currentIndex === -1) {
      if (musicList.length > 0) loadAndPlay(0);
      return;
    }
    if (audio.paused) {
      audio.play();
    } else {
      audio.pause();
    }
  }

  playPauseBtn.addEventListener('click', togglePlay);

  audio.addEventListener('play', () => {
    state.audio.isPlaying = true;
    playPauseBtn.textContent = '⏸';
    npDisc.classList.add('spinning');
    npStatus.textContent = 'Playing';
  });

  audio.addEventListener('pause', () => {
    state.audio.isPlaying = false;
    playPauseBtn.textContent = '▶';
    npDisc.classList.remove('spinning');
    npStatus.textContent = 'Paused';
  });

  audio.addEventListener('ended', () => {
    const next = state.audio.currentIndex + 1;
    if (next < musicList.length) {
      loadAndPlay(next);
    } else {
      // Reset
      state.audio.isPlaying = false;
      playPauseBtn.textContent = '▶';
      npDisc.classList.remove('spinning');
      npStatus.textContent = 'Ended';
    }
  });

  // ── Prev / Next ──────────────────────────────────
  prevBtn.addEventListener('click', () => {
    const prev = state.audio.currentIndex - 1;
    if (prev >= 0) loadAndPlay(prev);
  });

  nextBtn.addEventListener('click', () => {
    const next = state.audio.currentIndex + 1;
    if (next < musicList.length) loadAndPlay(next);
  });

  // ── Progress bar ─────────────────────────────────
  audio.addEventListener('timeupdate', () => {
    if (!audio.duration) return;
    const pct = (audio.currentTime / audio.duration) * 100;
    progressFill.style.width  = `${pct}%`;
    progressThumb.style.left  = `${pct}%`;
    timeElapsed.textContent   = formatTime(audio.currentTime);
  });

  audio.addEventListener('loadedmetadata', () => {
    timeDuration.textContent = formatTime(audio.duration);
  });

  // Click on progress bar to seek
  progressBar.addEventListener('click', (e) => {
    if (!audio.duration) return;
    const rect = progressBar.getBoundingClientRect();
    const pct  = (e.clientX - rect.left) / rect.width;
    audio.currentTime = pct * audio.duration;
  });

  // ── Volume ───────────────────────────────────────
  volumeSlider.addEventListener('input', () => {
    audio.volume = parseFloat(volumeSlider.value);
  });

  // ── Modal open / close ───────────────────────────
  window.openMusicModal = function () {
    modal.classList.remove('hidden');
    modal.classList.add('open');
    state.musicModalOpen = true;
    document.body.style.overflow = 'hidden';
  };

  function closeMusicModal() {
    modal.classList.add('hidden');
    modal.classList.remove('open');
    state.musicModalOpen = false;
    document.body.style.overflow = '';
  }

  closeBtn.addEventListener('click', closeMusicModal);
  backdrop.addEventListener('click', closeMusicModal);

  // Keyboard close
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && state.musicModalOpen) closeMusicModal();
  });
})();


/* ══════════════════════════════════════════════
   10. SCROLL ANIMATIONS — IntersectionObserver
══════════════════════════════════════════════ */

let scrollObserver = null;

function observeElements() {
  if (scrollObserver) scrollObserver.disconnect();

  scrollObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          scrollObserver.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
  );

  // Observe all animatable elements in current DOM
  document.querySelectorAll('.fade-up, .thought-card, .gallery-card').forEach(el => {
    if (!el.classList.contains('visible')) {
      scrollObserver.observe(el);
    }
  });
}


/* ══════════════════════════════════════════════
   11. UTILITIES
══════════════════════════════════════════════ */

/**
 * Safely escape HTML to prevent XSS.
 * @param {string} str
 * @returns {string}
 */
function escapeHTML(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

/**
 * Format seconds into MM:SS string.
 * @param {number} secs
 * @returns {string}
 */
function formatTime(secs) {
  if (isNaN(secs)) return '0:00';
  const m = Math.floor(secs / 60);
  const s = Math.floor(secs % 60);
  return `${m}:${String(s).padStart(2, '0')}`;
}


/* ══════════════════════════════════════════════
   INIT — run everything after DOM is ready
══════════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', () => {
  // Start observing scroll animations
  observeElements();

  // Also run after app is revealed (after unlock)
  const app = document.getElementById('app');
  app.addEventListener('animationend', () => {
    observeElements();
  }, { once: true });
});
